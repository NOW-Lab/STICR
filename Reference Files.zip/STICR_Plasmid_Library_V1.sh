#!/bin/bash
 
#Variables
READ1=$1 #complete path including file
READ2=$2 #complete path including file
OUTPUTDIR=$3
CORES=$4
INDEX_PATH=$5
Bowtie_Reference_Path=$6 #path to folder containing bowtie references
 
#Load path of samtools (un-hash and change to your path if you want to use this)
export PATH=$PATH:/path/to/samtools/
 
#Load path of bbduk (change to your path)
export PATH=$PATH:/path/to/bbmap/
 
#Calculate lengths
 
let "n = $CORES / 3"
 
 
#Optimized selection and trimming to standardize 5' end of read
bbduk.sh in=$READ2 out=stdout.fq maq=15 int=f| \
bbduk.sh in=stdin.fq out=stdout.fq k=17 literal=AGCAAACTGGGGCACAAGC ktrim=l out=stdout.fq hdist=2 edist=2 int=f minlen=64 maxlen=74 skipr2 int=f| \
repair.sh in1=stdin.fq in2=$READ1 out=stdout.fq repair int=t| \

#Sorting reads by viral index
bbduk.sh in=stdin.fq literal=GAATTATCGAATT k=12 restrictleft=14 hdist=1 out=stdout.fq outm1=$OUTPUTDIR/1_trim_R1.fastq.gz outm2=$OUTPUTDIR/1_trim_R2.fastq.gz int=t| \
bbduk.sh in=stdin.fq literal=GAATTGAGGAATT k=12 restrictleft=14 hdist=1 out=stdout.fq outm1=$OUTPUTDIR/3_trim_R1.fastq.gz outm2=$OUTPUTDIR/3_trim_R2.fastq.gz int=t | \
bbduk.sh in=stdin.fq ref=$INDEX_PATH/E_selections.fa k=25 hdist=2 restrictleft=27 outm1=$OUTPUTDIR/E_trim_R1.fastq.gz outm2=$OUTPUTDIR/E_trim_R2.fastq.gz out1=$OUTPUTDIR/Fail_R1.fastq.gz out2=$OUTPUTDIR/Fail_R2.fastq.gz int=t

 
#Make bits and align
 
bbduk.sh in=$OUTPUTDIR/E_trim_R2.fastq.gz out=stdout.fq ftl=6 ftr=20| bowtie --threads $n -S -n 2 --best $Bowtie_Reference_Path/Bit1_w_Empty - | samtools sort -n -@ $n | samtools view - | awk 'BEGIN {OFS="\t"}; {print $1,$3}' - > $OUTPUTDIR/E_bit1_hit.txt &
bbduk.sh in=$OUTPUTDIR/E_trim_R2.fastq.gz out=stdout.fq ftl=26 ftr=40| bowtie --threads $n -S -n 2 --best $Bowtie_Reference_Path/Bit2_w_Empty - | samtools sort -n -@ $n | samtools view - | awk 'BEGIN {OFS="\t"}; {print $1,$3}' - > $OUTPUTDIR/E_bit2_hit.txt &
bbduk.sh in=$OUTPUTDIR/E_trim_R2.fastq.gz out=stdout.fq ftl=46 ftr=60| bowtie --threads $n -S -n 2 --best $Bowtie_Reference_Path/Bit3_w_Empty - | samtools sort -n -@ $n | samtools view - | awk 'BEGIN {OFS="\t"}; {print $1,$3}' - > $OUTPUTDIR/E_bit3_hit.txt &
 
wait
 
bbduk.sh in=$OUTPUTDIR/1_trim_R2.fastq.gz out=stdout.fq ftl=14 ftr=28| bowtie --threads $n -S -n 2 --best $Bowtie_Reference_Path/Bit1_w_Empty - | samtools sort -n -@ $n | samtools view - | awk 'BEGIN {OFS="\t"}; {print $1,$3}' - > $OUTPUTDIR/1_bit1_hit.txt &
bbduk.sh in=$OUTPUTDIR/1_trim_R2.fastq.gz out=stdout.fq ftl=34 ftr=48| bowtie --threads $n -S -n 2 --best $Bowtie_Reference_Path/Bit2_w_Empty - | samtools sort -n -@ $n | samtools view - | awk 'BEGIN {OFS="\t"}; {print $1,$3}' - > $OUTPUTDIR/1_bit2_hit.txt &
bbduk.sh in=$OUTPUTDIR/1_trim_R2.fastq.gz out=stdout.fq ftl=54 ftr=68| bowtie --threads $n -S -n 2 --best $Bowtie_Reference_Path/Bit3_w_Empty - | samtools sort -n -@ $n | samtools view - | awk 'BEGIN {OFS="\t"}; {print $1,$3}' - > $OUTPUTDIR/1_bit3_hit.txt &
 
wait
 
bbduk.sh in=$OUTPUTDIR/3_trim_R2.fastq.gz out=stdout.fq ftl=14 ftr=28| bowtie --threads $n -S -n 2 --best $Bowtie_Reference_Path/Bit1_w_Empty - | samtools sort -n -@ $n | samtools view - | awk 'BEGIN {OFS="\t"}; {print $1,$3}' - > $OUTPUTDIR/3_bit1_hit.txt &
bbduk.sh in=$OUTPUTDIR/3_trim_R2.fastq.gz out=stdout.fq ftl=34 ftr=48| bowtie --threads $n -S -n 2 --best $Bowtie_Reference_Path/Bit2_w_Empty - | samtools sort -n -@ $n | samtools view - | awk 'BEGIN {OFS="\t"}; {print $1,$3}' - > $OUTPUTDIR/3_bit2_hit.txt &
bbduk.sh in=$OUTPUTDIR/3_trim_R2.fastq.gz out=stdout.fq ftl=54 ftr=68| bowtie --threads $n -S -n 2 --best $Bowtie_Reference_Path/Bit3_w_Empty - | samtools sort -n -@ $n | samtools view - | awk 'BEGIN {OFS="\t"}; {print $1,$3}' - > $OUTPUTDIR/3_bit3_hit.txt &
 
wait
 
#Trim UMI Files, turn them into ReadID sorted Bam file
 
bbduk.sh in=$OUTPUTDIR/E_trim_R1.fastq.gz out=stdout.fq ftl=2 ftr=16 | /home/rnd/bbmap/reformat.sh in=stdin.fq out=stdout.bam int=f| samtools sort -n -@ $CORES | samtools view - | awk 'BEGIN {OFS="\t"}; {print $1,$11}' - > $OUTPUTDIR/E_Insert_UMI.txt
bbduk.sh in=$OUTPUTDIR/1_trim_R1.fastq.gz out=stdout.fq ftl=2 ftr=16 | /home/rnd/bbmap/reformat.sh in=stdin.fq out=stdout.bam int=f| samtools sort -n -@ $CORES | samtools view - | awk 'BEGIN {OFS="\t"}; {print $1,$11}' - > $OUTPUTDIR/1_Insert_UMI.txt
bbduk.sh in=$OUTPUTDIR/3_trim_R1.fastq.gz out=stdout.fq ftl=2 ftr=16 | /home/rnd/bbmap/reformat.sh in=stdin.fq out=stdout.bam int=f| samtools sort -n -@ $CORES | samtools view - | awk 'BEGIN {OFS="\t"}; {print $1,$11}' - > $OUTPUTDIR/3_Insert_UMI.txt
 
 
#Join all fields together to make a flat file for umi_count

join -j 1 $OUTPUTDIR/E_bit1_hit.txt $OUTPUTDIR/E_bit2_hit.txt -o1.1,1.2,2.2 > $OUTPUTDIR/E_part1.txt
join -j 1 $OUTPUTDIR/E_part1.txt $OUTPUTDIR/E_bit3_hit.txt -o1.1,1.2,1.3,2.2 > $OUTPUTDIR/E_part2.txt
join -j 1 $OUTPUTDIR/E_part2.txt $OUTPUTDIR/E_Insert_UMI.txt -o1.1,1.2,1.3,1.4,2.2 |awk 'BEGIN {OFS="\t"}; {print $1"_"$5,$2"-"$3"-"$4}' - |  sort -k2 -S 50% --parallel=$CORES - > $OUTPUTDIR/E_flat.txt


join -j 1 $OUTPUTDIR/1_bit1_hit.txt $OUTPUTDIR/1_bit2_hit.txt -o1.1,1.2,2.2 > $OUTPUTDIR/1_part1.txt
join -j 1 $OUTPUTDIR/1_part1.txt $OUTPUTDIR/1_bit3_hit.txt -o1.1,1.2,1.3,2.2 > $OUTPUTDIR/1_part2.txt
join -j 1 $OUTPUTDIR/1_part2.txt $OUTPUTDIR/1_Insert_UMI.txt -o1.1,1.2,1.3,1.4,2.2 |awk 'BEGIN {OFS="\t"}; {print $1"_"$5,$2"-"$3"-"$4}' - |  sort -k2 -S 50% --parallel=$CORES - > $OUTPUTDIR/1_flat.txt

join -j 1 $OUTPUTDIR/3_bit1_hit.txt $OUTPUTDIR/3_bit2_hit.txt -o1.1,1.2,2.2 > $OUTPUTDIR/3_part1.txt
join -j 1 $OUTPUTDIR/3_part1.txt $OUTPUTDIR/3_bit3_hit.txt -o1.1,1.2,1.3,2.2 > $OUTPUTDIR/3_part2.txt
join -j 1 $OUTPUTDIR/3_part2.txt $OUTPUTDIR/3_Insert_UMI.txt -o1.1,1.2,1.3,1.4,2.2 |awk 'BEGIN {OFS="\t"}; {print $1"_"$5,$2"-"$3"-"$4}' - |  sort -k2 -S 50% --parallel=$CORES - > $OUTPUTDIR/3_flat.txt


#Perform UMI Reduction
umi_tools count_tab --edit-distance-threshold=1 -I $OUTPUTDIR/E_flat.txt -S $OUTPUTDIR/counts_E.tsv -L $OUTPUTDIR/E_count.log &
umi_tools count_tab --edit-distance-threshold=1 -I $OUTPUTDIR/1_flat.txt -S $OUTPUTDIR/counts_1.tsv -L $OUTPUTDIR/1_count.log &
umi_tools count_tab --edit-distance-threshold=1 -I $OUTPUTDIR/3_flat.txt -S $OUTPUTDIR/counts_3.tsv -L $OUTPUTDIR/3_count.log &
 
wait
 

#Concatenate umi-collapsed VBCs
 
cat $OUTPUTDIR/counts_E.tsv $OUTPUTDIR/counts_1.tsv $OUTPUTDIR/counts_3.tsv | sort | uniq | awk 'BEGIN {OFS="\t"}; {print $1, $2, $3}' - > $OUTPUTDIR/Final_Barcodes.tsv
 
sed -i '/*/d' $OUTPUTDIR/Final_Barcodes.tsv
 
#Cleanup 2
rm $OUTPUTDIR/3_bit3_hit.txt
rm $OUTPUTDIR/3_bit2_hit.txt
rm $OUTPUTDIR/3_bit1_hit.txt
rm $OUTPUTDIR/1_bit3_hit.txt
rm $OUTPUTDIR/1_bit2_hit.txt
rm $OUTPUTDIR/1_bit1_hit.txt
rm $OUTPUTDIR/E_bit3_hit.txt
rm $OUTPUTDIR/E_bit2_hit.txt
rm $OUTPUTDIR/E_bit1_hit.txt
rm $OUTPUTDIR/E_part1.txt
rm $OUTPUTDIR/E_part2.txt
rm $OUTPUTDIR/1_part1.txt
rm $OUTPUTDIR/1_part2.txt
rm $OUTPUTDIR/3_part1.txt
rm $OUTPUTDIR/3_part2.txt
rm $OUTPUTDIR/E_trim_R1.fastq.gz
rm $OUTPUTDIR/E_trim_R2.fastq.gz
rm $OUTPUTDIR/1_trim_R1.fastq.gz
rm $OUTPUTDIR/1_trim_R2.fastq.gz
rm $OUTPUTDIR/3_trim_R1.fastq.gz
rm $OUTPUTDIR/3_trim_R2.fastq.gz
rm $OUTPUTDIR/E_Insert_UMI.txt
rm $OUTPUTDIR/1_Insert_UMI.txt
rm $OUTPUTDIR/3_Insert_UMI.txt
rm $OUTPUTDIR/Fail_R1.fastq.gz
rm $OUTPUTDIR/Fail_R2.fastq.gz

 
 
#Rscript /home/rnd/Scripts/Test_bash_to_R_Command.R $OUTPUTDIR $CBC_Path